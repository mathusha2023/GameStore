# DDOS_Booster

Add the script like the [DDOS_Telegram_BOT](https://github.com/Mehliug-git/DDOS_Telegram_BOT) but withouy Telegram ! 
Just setup this like the Telegram bot and for start DDOS just go to the like http://your-domain-bot.com/stress?http://the-url-to-ddos.com and the DDOS start automatically !
